# ClearCV Website

A responsive static website for an AI-assisted CV / job-application service.

## Files
- index.html — page structure/content
- styles.css — responsive styling
- script.js — mobile navigation, year, and demo contact form

## Before publishing
1. Replace `hello@clearcv.example` in `index.html` and `script.js` with your real email.
2. Replace the placeholder phone number and any business details.
3. Replace the example testimonial with a real testimonial only after you have permission.
4. Connect the form to a form backend (Formspree, Netlify Forms, your own server, etc.) if you want submissions without the customer's email app.
5. Add your privacy policy/terms if you collect personal data or take payments.

## Publish
Upload `index.html`, `styles.css`, and `script.js` to any static hosting provider. No build step is required.
